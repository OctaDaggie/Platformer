var game = new Phaser.Game(1024, 521, Phaser.AUTO,'', {
    preload: preload,
    update: update,
    create: create
});

var jumpTimer = 0;

function preload() {
    game.load.image("tileset", "assets/tileset.png");
    game.load.tilemap("map", "assets/untitled.json", null, Phaser.Tilemap.TILED_JSON);
    game.load.spritesheet("player_sprite", "assets/LightBandit_Spritesheet.png", 48,48);
}

function create() {

    game.physics.startSystem(Phaser.Physics.ARRAY_BUFFER);

    var map = game.add.tilemap("map", 64, 64, 16, 8);
    map.addTilesetImage("tileset");
    background = map.createLayer("Background_Layer");
    foreground = map.createLayer("Foreground_Layer");
    trapground = map.createLayer("Trap_Layer");
    map.setCollision([1,2,3,24,25,27,28,48,52,72,76,97,98,99], true, "Foreground_Layer");
    map.setCollision([166,189,214,191], true, "Trap_Layer");
    background.resizeWorld();


    player = game.add.sprite(1, 4, 'player_sprite', 1);
    player.animations.add('walk', [9,10,11], 8, true);
    player.animations.add('idle', [1,2,3], 6, false);
    player.animations.add('jump', [8,9,10], 4, true );
    game.physics.enable(player, Phaser.Physics.ARCADE);
    game.camera.follow(player, Phaser.Camera.LOCKON, 0.1, 0.1);
    player.body.collideWorldBounds = true;
    player.anchor.setTo(.5,.5);


    cursors = game.input.keyboard.createCursorKeys();
    jumpButton = game.input.keyboard.addKey(Phaser.Keyboard.SPACEBAR);
}

function update() {

    player.body.gravity.y = 500;
    game.physics.arcade.collide(player, foreground, function() {
        player.body.gravity.y = 0;
    });
    game.physics.arcade.collide(player, trapground, function() {
        console.log("aaa");
    });

    player.body.velocity.x = 0;

    if (cursors.right.isDown)
    {
        player.animations.play('walk');
        player.body.velocity.x = 150;
    }
    else if(cursors.right.isUp){
        player.animations.play('idle');
        player.scale.x = -1;
    }

    if (cursors.left.isDown){
        player.animations.play('walk');
        player.body.velocity.x = -150;
        player.scale.x = 1;


    }
    else if(cursors.right.isUp){
        player.animations.play('idle');
        player.scale.x = -1;
    }
    if (jumpButton.isDown && player.body.onFloor() && game.time.now > jumpTimer)
    {
        player.body.velocity.y = -250;
        jumpTimer = game.time.now + 750;
    }

}

function render(){
    game.debug.cameraInfo(game.camera, 32, 32);
}